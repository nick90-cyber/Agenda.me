import React, { useState } from "react";
import { format, startOfWeek, addDays, isSameDay, startOfMonth, endOfMonth, eachDayOfInterval } from "date-fns";
import { motion } from "framer-motion";

export default function App() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [events, setEvents] = useState([
    { date: new Date(), title: "Reunião com equipe" }
  ]);

  const start = startOfMonth(currentDate);
  const end = endOfMonth(currentDate);
  const days = eachDayOfInterval({ start, end });

  const handleAddEvent = (day) => {
    const title = prompt("Nome do evento:");
    if (title) {
      setEvents([...events, { date: day, title }]);
    }
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Calendário estilo Notion</h1>
      <div className="grid grid-cols-7 gap-2">
        {days.map((day, idx) => {
          const dayEvents = events.filter((e) => isSameDay(e.date, day));
          return (
            <motion.div
              key={idx}
              className="border rounded-xl p-2 bg-white shadow-sm cursor-pointer hover:shadow-md transition"
              whileHover={{ scale: 1.02 }}
              onClick={() => handleAddEvent(day)}
            >
              <div className="font-semibold text-sm">{format(day, "d")}</div>
              <div className="mt-1 space-y-1">
                {dayEvents.map((event, i) => (
                  <div key={i} className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-lg">
                    {event.title}
                  </div>
                ))}
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
